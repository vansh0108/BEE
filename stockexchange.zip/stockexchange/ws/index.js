// Forwarding entry so old "node index" command still works after moving code into ./api
require('../api/index.js');
